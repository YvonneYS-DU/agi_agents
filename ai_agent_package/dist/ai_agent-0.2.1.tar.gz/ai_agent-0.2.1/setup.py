"""
Setup script for LLM Wrapper package.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ai-agent",
    version="0.2.1",
    author="YvonneYS-Du",
    author_email="yvdu.ai2077@gmail.com",
    description="A streamlined interface for LangChain AI agent creation with multi-modal support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/YvonneYS-DU/ai_agent",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    install_requires=[
        # LangChain ecosystem - strict version control
        "langchain>=0.3.0,<0.4.0",
        "langchain-core>=0.3.5,<0.4.0",
        "langchain-openai>=0.1.0",
        "langchain-anthropic>=0.1.0", 
        "langchain-text-splitters>=0.3.0",
        
        # AI API clients - strict version control
        "openai>=1.76.0,<2.0.0",
        "anthropic>=0.40.0,<1.0.0",
        
        # HTTP clients - strict version limits
        "httpx>=0.27.2,<0.28.0",
        "aiohttp>=3.8.0",
        "aiofiles>=23.0.0",
        
        # Document processing
        "PyMuPDF>=1.20.0",
        "python-docx>=1.0.0",
        "unstructured>=0.15.0",
        "openpyxl>=3.1.0",
        
        # Image processing
        "Pillow>=9.0.0",
        "pillow-heif>=0.8.0",
        
        # Data processing
        "pandas>=1.5.0",
        "regex>=2020.1.1",
        
        # Azure support
        "azure-storage-blob>=12.0.0",
        
        # Utilities
        "python-dotenv>=1.0.0",
        "urllib3>=2.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.900",
        ],
        "docs": [
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=1.0.0",
        ],
    },
    keywords="langchain, ai, llm, multimodal, agents, wrapper",
    project_urls={
        "Bug Reports": "https://github.com/YvonneYS-DU/ai_agent/issues",
        "Source": "https://github.com/YvonneYS-DU/ai_agent",
    },
)